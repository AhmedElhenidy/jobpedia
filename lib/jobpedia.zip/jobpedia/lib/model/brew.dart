class Brew{
  final String name,sugars;
  int strength;
  Brew({this.name,this.strength,this.sugars});
}