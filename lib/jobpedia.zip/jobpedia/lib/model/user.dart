class User{
   String uid ;
  String name;
  int phone;
  String govern ;
  String note;
  String specialize;
  User({this.name,this.note,this.phone,this.govern,this.specialize,this.uid});
}