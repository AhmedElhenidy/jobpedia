import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:jobpedia/model/user.dart';
class DatabaseService{
  String uid;
  DatabaseService({this.uid});
  // collection refrence
  final CollectionReference userCollection = Firestore.instance.collection('users');
   Future updateUserData( {String name ,String phone,String govern,String note,String specialize}) async{
     print("from user set data : :  ");
     return await userCollection.document(uid).setData({
       'name':name,
       'phone' :phone,
       'govern': govern,
       'note':note,
       'specialize':specialize,
       'id':uid,
     });
   }
   //brew list of snap shot
  List<User> _userListFromSnapshot(QuerySnapshot snapshot){
     print("user list from snap shot:::::");
     return snapshot.documents.map((doc){
       return User(
         name: doc.data['name']??'',
         govern: doc.data['govern']??'',
         note: doc.data['note']??'',
         specialize: doc.data['specialize']??'',
         phone: doc.data['phone']??0,
         uid : doc.data['id']??''

       );
     }).toList();
  }
   Stream<List<User>> get users{
     print("from stream : : :  ");
     return userCollection.snapshots()
         .map(_userListFromSnapshot);
   }
}