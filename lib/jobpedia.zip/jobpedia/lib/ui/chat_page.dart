import 'package:flutter/material.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
class ChatPage extends StatefulWidget {
  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: Colors.white,
      child:ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: 12,
        itemBuilder: (context,position){
          return Container(
            padding: EdgeInsets.all(8),
            child: ListTile(
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text("Mohamed Ahmed",
                        style: TextStyle(
                          fontWeight: FontWeight.w700
                        ),
                      ),
                      Text("yesterday",
                        style: TextStyle(
                          fontSize: 12
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text("صباح الخير.."),
                      SmoothStarRating(
                          allowHalfRating: true,
                          /*onRatingChanged: (v) {
                            rating = v;
                            setState(() {});
                          },*/
                          starCount: 5,
                          rating: 2.5,
                          size: 20.0,
                          color: Colors.yellow,
                          borderColor: Colors.yellowAccent,
                          spacing:0.0
                      )
                    ],
                  ),
                ],
              ),
              leading:CircleAvatar(
                radius: 30,
                foregroundColor: Colors.black12,
              ),
            ),
          );
        },
      ),
    );
  }
}
