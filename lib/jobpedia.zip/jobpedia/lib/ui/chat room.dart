import 'package:flutter/material.dart';
class ChatRoom  extends StatefulWidget {
  @override
  _ChatRoomState createState() => _ChatRoomState();
}

class _ChatRoomState extends State<ChatRoom > {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
